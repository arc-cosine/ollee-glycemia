package pl.cukrzycowy.ollee.glycemia

import com.google.gson.JsonParser
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.HttpURLConnection
import java.net.URI
import kotlin.concurrent.thread

class GoogleHealthApiTest {

    @Test
    fun pkceChallengeMatchesRfc7636Example() {
        assertEquals(
            "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM",
            GoogleHealthApi.codeChallengeS256("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk")
        )
        val verifier = GoogleHealthApi.newCodeVerifier()
        assertEquals(64, verifier.length)
        assertTrue(verifier.all { it.isLetterOrDigit() || it == '-' || it == '_' })
    }

    @Test
    fun base64UrlRoundTrip() {
        for (len in 0..40) {
            val bytes = ByteArray(len) { (it * 37 + len).toByte() }
            val encoded = GoogleHealthApi.base64Url(bytes)
            assertFalse(encoded.contains('=') || encoded.contains('+') || encoded.contains('/'))
            assertArrayEquals(bytes, GoogleHealthApi.base64UrlDecode(encoded))
        }
        assertNull(GoogleHealthApi.base64UrlDecode("not base64!"))
    }

    @Test
    fun authUrlCarriesPkceAndScopes() {
        val url = GoogleHealthApi.buildAuthUrl("1-x.apps.googleusercontent.com", "http://127.0.0.1:4321", "CHAL", "STATE")
        assertTrue(url.startsWith(GoogleHealthApi.AUTH_ENDPOINT + "?"))
        val q = GoogleHealthApi.parseQuery(url.substringAfter('?'))
        assertEquals("1-x.apps.googleusercontent.com", q["client_id"])
        assertEquals("http://127.0.0.1:4321", q["redirect_uri"])
        assertEquals("code", q["response_type"])
        assertEquals("CHAL", q["code_challenge"])
        assertEquals("S256", q["code_challenge_method"])
        assertEquals("STATE", q["state"])
        assertTrue(q["scope"]!!.split(' ').contains(GoogleHealthApi.SCOPE_ACTIVITY))
    }

    @Test
    fun stepsRequestMatchesDailyRollUpShape() {
        val body = JsonParser.parseString(
            GoogleHealthApi.stepsRequestJson(GoogleHealthApi.CivilDate(2026, 2, 26), null, GoogleHealthApi.SOURCE_ALL)
        )
        val expected = JsonParser.parseString(
            """{"range":{"start":{"date":{"year":2026,"month":2,"day":26},"time":{"hours":0,"minutes":0,"seconds":0,"nanos":0}},""" +
                """"end":{"date":{"year":2026,"month":2,"day":26},"time":{"hours":23,"minutes":59,"seconds":59,"nanos":0}}},"windowSizeDays":1}"""
        )
        assertEquals(expected, body)

        val wearables = JsonParser.parseString(
            GoogleHealthApi.stepsRequestJson(GoogleHealthApi.CivilDate(2026, 2, 26), GoogleHealthApi.CivilTime(0, 0, 0), GoogleHealthApi.SOURCE_WEARABLES)
        ).asJsonObject
        assertEquals("users/me/dataSourceFamilies/google-wearables", wearables.get("dataSourceFamily").asString)
        assertEquals(1, wearables.getAsJsonObject("range").getAsJsonObject("end").getAsJsonObject("time").get("seconds").asInt)
    }

    @Test
    fun parsesStepsResponse() {
        val doc = """{"rollupDataPoints":[{"civilStartTime":{"date":{"year":2026,"month":2,"day":26},"time":{}},""" +
            """"civilEndTime":{"date":{"year":2026,"month":2,"day":26},"time":{"hours":23,"minutes":59,"seconds":59}},"steps":{"countSum":"3822"}}]}"""
        assertEquals(GoogleHealthApi.StepsParse.Ok(3822, false), GoogleHealthApi.parseStepsResponse(doc))
        assertEquals(GoogleHealthApi.StepsParse.Ok(0, true), GoogleHealthApi.parseStepsResponse("""{"rollupDataPoints":[]}"""))
        assertEquals(GoogleHealthApi.StepsParse.Ok(0, true), GoogleHealthApi.parseStepsResponse("{}"))
        assertTrue(GoogleHealthApi.parseStepsResponse("""{"rollupDataPoints":[{"distance":{}}]}""") is GoogleHealthApi.StepsParse.Bad)
        assertTrue(GoogleHealthApi.parseStepsResponse("<html>") is GoogleHealthApi.StepsParse.Bad)
    }

    @Test
    fun formatsStepsForTheSixWatchDigits() {
        assertEquals("     0", GoogleHealthApi.formatForWatch(0))
        assertEquals("  8432", GoogleHealthApi.formatForWatch(8432))
        assertEquals(" 12345", GoogleHealthApi.formatForWatch(12345))
        assertEquals("999999", GoogleHealthApi.formatForWatch(5_000_000))
    }

    @Test
    fun readsErrorsAndIdToken() {
        assertEquals(
            Pair("invalid_grant", "Token has been expired or revoked."),
            GoogleHealthApi.oauthError("""{"error":"invalid_grant","error_description":"Token has been expired or revoked."}""")
        )
        assertEquals(
            "PERMISSION_DENIED: API disabled",
            GoogleHealthApi.apiErrorMessage("""{"error":{"code":403,"message":"API disabled","status":"PERMISSION_DENIED"}}""")
        )
        val payload = GoogleHealthApi.base64Url("""{"email":"someone@example.com"}""".toByteArray())
        assertEquals("someone@example.com", GoogleHealthApi.emailFromIdToken("e30.$payload.sig"))
        val tokens = GoogleHealthApi.parseTokenResponse(
            """{"access_token":"A","expires_in":3599,"refresh_token":"R","scope":"openid ${GoogleHealthApi.SCOPE_ACTIVITY}"}"""
        )!!
        assertTrue(tokens.hasScope(GoogleHealthApi.SCOPE_ACTIVITY))
        assertFalse(tokens.copy(scope = "openid email").hasScope(GoogleHealthApi.SCOPE_ACTIVITY))
    }

    @Test
    fun loopbackReceiverGetsTheRedirect() {
        val receiver = GoogleHealthApi.LoopbackReceiver("OK", "FAIL")
        var page = ""
        val browser = thread {
            Thread.sleep(100)
            val c = URI("${receiver.redirectUri}/?state=S1&code=4%2F0Abc&scope=email").toURL().openConnection() as HttpURLConnection
            page = c.inputStream.use { String(it.readBytes()) }
        }
        val result = receiver.await("S1", 5000)
        browser.join()
        receiver.close()
        assertEquals("4/0Abc", result.code)
        assertTrue(result.stateMatches)
        assertNull(result.error)
        assertEquals("OK", page)
    }
}
