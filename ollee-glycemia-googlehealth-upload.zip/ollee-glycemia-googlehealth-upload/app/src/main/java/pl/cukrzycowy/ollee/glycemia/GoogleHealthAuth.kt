package pl.cukrzycowy.ollee.glycemia

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException
import java.net.SocketException
import java.net.SocketTimeoutException

/** What the Google Health settings screen shows about the sign-in. */
data class GoogleHealthAuthState(
    val signedIn: Boolean = false,
    val email: String? = null,
    val inProgress: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false
)

/**
 * Google sign-in for [GoogleHealthProvider], using the user's own OAuth client
 * ("Desktop app" type) entered in the provider settings. The phone's browser shows
 * Google's page and comes back to a one-shot listener on 127.0.0.1 (PKCE protected).
 * Tokens live in a private preferences file that is never part of the app's backups.
 */
object GoogleHealthAuth {

    private const val TAG = "GoogleHealthAuth"
    private const val PREFS_NAME = "google_health_auth"
    private const val KEY_CLIENT_SECRET = "client_secret"
    private const val KEY_ACCESS_TOKEN = "access_token"
    private const val KEY_EXPIRES_AT = "access_token_expires_at"
    private const val KEY_REFRESH_TOKEN = "refresh_token"
    private const val KEY_TOKEN_CLIENT_ID = "token_client_id"
    private const val KEY_EMAIL = "email"
    private const val SIGN_IN_TIMEOUT_MS = 5 * 60 * 1000L
    private const val EXPIRY_MARGIN_MS = 60 * 1000L

    private val _state = MutableStateFlow(GoogleHealthAuthState())
    val state: StateFlow<GoogleHealthAuthState> = _state.asStateFlow()

    @Volatile
    private var pendingReceiver: GoogleHealthApi.LoopbackReceiver? = null

    sealed class TokenResult {
        data class Ok(val accessToken: String) : TokenResult()
        data class NotSignedIn(val reason: String) : TokenResult()
        data class Failed(
            val status: GoogleHealthFetchStatus,
            val reason: String,
            val httpCode: Int? = null
        ) : TokenResult()
    }

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ========================
    // STORED VALUES
    // ========================

    /** Kept here rather than in the provider config, so preference backups never contain it. */
    fun getClientSecret(context: Context): String =
        prefs(context).getString(KEY_CLIENT_SECRET, "") ?: ""

    fun setClientSecret(context: Context, secret: String) {
        prefs(context).edit().putString(KEY_CLIENT_SECRET, secret.trim()).apply()
    }

    fun isSignedIn(context: Context): Boolean {
        val p = prefs(context)
        return p.getString(KEY_REFRESH_TOKEN, null) != null || p.getString(KEY_ACCESS_TOKEN, null) != null
    }

    fun signedInEmail(context: Context): String? = prefs(context).getString(KEY_EMAIL, null)

    /** Re-reads the stored sign-in for the settings screen; keeps a sign-in that is still running. */
    fun loadState(context: Context) {
        val current = _state.value
        val signedIn = isSignedIn(context)
        val email = signedInEmail(context)
        _state.value = if (current.inProgress) {
            current.copy(signedIn = signedIn, email = email)
        } else {
            GoogleHealthAuthState(signedIn = signedIn, email = email)
        }
    }

    // ========================
    // SIGN-IN
    // ========================

    /** Opens Google's sign-in page in the browser; the result arrives in [state]. */
    fun startSignIn(context: Context, clientId: String, clientSecret: String) {
        val appContext = context.applicationContext
        val id = clientId.trim()
        val secret = clientSecret.trim()
        if (id.isEmpty()) {
            publishError(appContext, appContext.getString(R.string.provider_google_health_error_client_id_missing))
            return
        }
        cancelPendingSignIn()

        val receiver = try {
            GoogleHealthApi.LoopbackReceiver(
                successHtml = GoogleHealthApi.htmlPage(
                    appContext.getString(R.string.provider_google_health_browser_done_title),
                    appContext.getString(R.string.provider_google_health_browser_done_body)
                ),
                failureHtml = GoogleHealthApi.htmlPage(
                    appContext.getString(R.string.provider_google_health_browser_failed_title),
                    appContext.getString(R.string.provider_google_health_browser_failed_body)
                )
            )
        } catch (e: IOException) {
            publishError(appContext, networkMessage(appContext, e))
            return
        }
        pendingReceiver = receiver

        val verifier = GoogleHealthApi.newCodeVerifier()
        val expectedState = GoogleHealthApi.newState()
        val authUrl = GoogleHealthApi.buildAuthUrl(
            clientId = id,
            redirectUri = receiver.redirectUri,
            codeChallenge = GoogleHealthApi.codeChallengeS256(verifier),
            state = expectedState
        )

        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(authUrl))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            pendingReceiver = null
            receiver.close()
            publishError(appContext, appContext.getString(R.string.provider_google_health_error_no_browser))
            return
        }

        _state.value = _state.value.copy(
            inProgress = true,
            message = appContext.getString(R.string.provider_google_health_waiting_browser),
            isError = false
        )

        Thread {
            try {
                val redirect = receiver.await(expectedState, SIGN_IN_TIMEOUT_MS)
                val code = redirect.code
                if (pendingReceiver === receiver) {
                    if (redirect.error != null) {
                        publishError(
                            appContext,
                            appContext.getString(R.string.provider_google_health_error_denied, redirect.error)
                        )
                    } else if (!redirect.stateMatches || code == null) {
                        publishError(appContext, appContext.getString(R.string.provider_google_health_error_state))
                    } else {
                        finishSignIn(appContext, id, secret, code, verifier, receiver.redirectUri)
                    }
                }
            } catch (e: SocketTimeoutException) {
                if (pendingReceiver === receiver) {
                    publishError(appContext, appContext.getString(R.string.provider_google_health_error_timeout))
                }
            } catch (e: SocketException) {
                // Closed by cancelPendingSignIn(): a newer attempt (or nobody) owns the state now.
                if (pendingReceiver === receiver) publishError(appContext, networkMessage(appContext, e))
            } catch (e: GoogleHealthException) {
                if (pendingReceiver === receiver) publishError(appContext, e.message ?: "Google error")
            } catch (e: IOException) {
                if (pendingReceiver === receiver) publishError(appContext, networkMessage(appContext, e))
            } finally {
                receiver.close()
                if (pendingReceiver === receiver) pendingReceiver = null
            }
        }.start()
    }

    private fun finishSignIn(
        context: Context,
        clientId: String,
        clientSecret: String,
        code: String,
        verifier: String,
        redirectUri: String
    ) {
        val tokens = GoogleHealthApi.exchangeCode(code, verifier, clientId, clientSecret, redirectUri)
        if (!tokens.hasScope(GoogleHealthApi.SCOPE_ACTIVITY)) {
            GoogleHealthApi.revokeToken(tokens.accessToken)
            publishError(context, context.getString(R.string.provider_google_health_error_scope))
            return
        }
        val email = GoogleHealthApi.emailFromIdToken(tokens.idToken)
        val editor = prefs(context).edit()
        editor.putString(KEY_ACCESS_TOKEN, tokens.accessToken)
        editor.putLong(KEY_EXPIRES_AT, System.currentTimeMillis() + tokens.expiresInSec * 1000L)
        editor.putString(KEY_TOKEN_CLIENT_ID, clientId)
        if (tokens.refreshToken != null) {
            editor.putString(KEY_REFRESH_TOKEN, tokens.refreshToken)
        } else {
            editor.remove(KEY_REFRESH_TOKEN)
        }
        if (email != null) editor.putString(KEY_EMAIL, email) else editor.remove(KEY_EMAIL)
        editor.apply()

        val hasRefresh = tokens.refreshToken != null
        _state.value = GoogleHealthAuthState(
            signedIn = true,
            email = email,
            inProgress = false,
            message = context.getString(
                if (hasRefresh) R.string.provider_google_health_sign_in_ok
                else R.string.provider_google_health_no_refresh_token
            ),
            isError = !hasRefresh
        )
        Log.d(TAG, "Signed in (refresh token: $hasRefresh)")
        GoogleHealthProvider.refreshRunningProvider()
    }

    fun cancelPendingSignIn() {
        val previous = pendingReceiver
        pendingReceiver = null
        previous?.close()
        val current = _state.value
        if (current.inProgress) _state.value = current.copy(inProgress = false, message = null)
    }

    fun signOut(context: Context) {
        cancelPendingSignIn()
        val p = prefs(context)
        val toRevoke = p.getString(KEY_REFRESH_TOKEN, null) ?: p.getString(KEY_ACCESS_TOKEN, null)
        clearTokens(context)
        _state.value = GoogleHealthAuthState(signedIn = false)
        if (toRevoke != null) Thread { GoogleHealthApi.revokeToken(toRevoke) }.start()
    }

    private fun clearTokens(context: Context) {
        prefs(context).edit()
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_EXPIRES_AT)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_TOKEN_CLIENT_ID)
            .remove(KEY_EMAIL)
            .apply()
    }

    // ========================
    // ACCESS TOKEN
    // ========================

    /** A usable access token, refreshing it with the refresh token when it is (nearly) expired. */
    @Synchronized
    fun getValidAccessToken(context: Context, forceRefresh: Boolean = false): TokenResult {
        val p = prefs(context)
        val access = p.getString(KEY_ACCESS_TOKEN, null)
        val refresh = p.getString(KEY_REFRESH_TOKEN, null)
        if (access == null && refresh == null) {
            return TokenResult.NotSignedIn(context.getString(R.string.provider_google_health_not_signed_in))
        }

        val tokenClientId = p.getString(KEY_TOKEN_CLIENT_ID, null) ?: ""
        val configuredClientId = GoogleHealthProvider.savedClientId(context)
        if (configuredClientId.isNotEmpty() && tokenClientId.isNotEmpty() && configuredClientId != tokenClientId) {
            return TokenResult.NotSignedIn(context.getString(R.string.provider_google_health_error_client_changed))
        }

        val now = System.currentTimeMillis()
        if (!forceRefresh && access != null && now < p.getLong(KEY_EXPIRES_AT, 0L) - EXPIRY_MARGIN_MS) {
            return TokenResult.Ok(access)
        }
        if (refresh == null) {
            return TokenResult.NotSignedIn(context.getString(R.string.provider_google_health_error_expired))
        }

        return try {
            val tokens = GoogleHealthApi.refreshAccessToken(
                refreshToken = refresh,
                clientId = tokenClientId.ifEmpty { configuredClientId },
                clientSecret = getClientSecret(context)
            )
            val editor = p.edit()
            editor.putString(KEY_ACCESS_TOKEN, tokens.accessToken)
            editor.putLong(KEY_EXPIRES_AT, now + tokens.expiresInSec * 1000L)
            if (tokens.refreshToken != null) editor.putString(KEY_REFRESH_TOKEN, tokens.refreshToken)
            editor.apply()
            TokenResult.Ok(tokens.accessToken)
        } catch (e: GoogleHealthException) {
            if (e.oauthError == "invalid_grant") {
                // Revoked, or the 7-day limit of OAuth apps in "Testing" mode.
                clearTokens(context)
                val message = context.getString(R.string.provider_google_health_error_expired)
                _state.value = GoogleHealthAuthState(signedIn = false, message = message, isError = true)
                TokenResult.NotSignedIn(message)
            } else {
                TokenResult.Failed(GoogleHealthFetchStatus.AUTH_ERROR, e.message ?: "OAuth error", e.httpCode)
            }
        } catch (e: IOException) {
            TokenResult.Failed(GoogleHealthFetchStatus.CONNECTION_ERROR, networkMessage(context, e))
        }
    }

    // ========================
    // HELPERS
    // ========================

    private fun networkMessage(context: Context, e: Exception): String =
        context.getString(R.string.provider_google_health_error_network, e.message ?: e.javaClass.simpleName)

    private fun publishError(context: Context, message: String) {
        Log.w(TAG, message)
        _state.value = GoogleHealthAuthState(
            signedIn = isSignedIn(context),
            email = signedInEmail(context),
            inProgress = false,
            message = message,
            isError = true
        )
    }
}
