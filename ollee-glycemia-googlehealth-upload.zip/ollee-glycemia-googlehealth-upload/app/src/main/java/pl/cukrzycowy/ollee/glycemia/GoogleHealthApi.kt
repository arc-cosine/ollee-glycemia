package pl.cukrzycowy.ollee.glycemia

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

/** Error answered by Google (OAuth or API), with the HTTP code and the OAuth `error` value when present. */
class GoogleHealthException(
    message: String,
    val httpCode: Int? = null,
    val oauthError: String? = null
) : Exception(message)

/**
 * Plain-JVM helpers behind [GoogleHealthProvider]: OAuth 2.0 for installed apps
 * (PKCE + loopback redirect, as Google documents for desktop clients), the steps
 * `dailyRollUp` request, response parsing and the 6-character watch text.
 * No Android imports, so everything here can be unit-tested on the JVM.
 */
object GoogleHealthApi {

    const val AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
    const val TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
    const val REVOKE_ENDPOINT = "https://oauth2.googleapis.com/revoke"
    const val API_BASE = "https://health.googleapis.com/v4"

    /** Read-only scope that covers steps (activity and fitness data). */
    const val SCOPE_ACTIVITY = "https://www.googleapis.com/auth/googlehealth.activity_and_fitness.readonly"

    /** `openid email` only let the settings screen show which Google account is signed in. */
    val SCOPES: List<String> = listOf("openid", "email", SCOPE_ACTIVITY)

    const val SOURCE_ALL = "all-sources"
    const val SOURCE_WEARABLES = "google-wearables"
    private const val SOURCE_PREFIX = "users/me/dataSourceFamilies/"

    /** Endpoints actually used; only tests point these at a local fake server. */
    @Volatile internal var tokenUrl: String = TOKEN_ENDPOINT
    @Volatile internal var revokeUrl: String = REVOKE_ENDPOINT
    @Volatile internal var apiBaseUrl: String = API_BASE

    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 20_000

    private val secureRandom = SecureRandom()

    // ========================
    // PKCE / RANDOM
    // ========================

    /** 48 random bytes -> 64 chars, inside RFC 7636's 43..128 range. */
    fun newCodeVerifier(): String = base64Url(randomBytes(48))

    fun newState(): String = base64Url(randomBytes(16))

    fun codeChallengeS256(verifier: String): String =
        base64Url(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)))

    private fun randomBytes(count: Int): ByteArray = ByteArray(count).also { secureRandom.nextBytes(it) }

    private const val B64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    /** Base64url without padding (java.util.Base64 needs API 26; minSdk is 24). */
    fun base64Url(data: ByteArray): String {
        val sb = StringBuilder((data.size * 4 + 2) / 3)
        var i = 0
        while (i + 3 <= data.size) {
            val n = ((data[i].toInt() and 0xFF) shl 16) or
                ((data[i + 1].toInt() and 0xFF) shl 8) or
                (data[i + 2].toInt() and 0xFF)
            sb.append(B64URL[(n ushr 18) and 63])
                .append(B64URL[(n ushr 12) and 63])
                .append(B64URL[(n ushr 6) and 63])
                .append(B64URL[n and 63])
            i += 3
        }
        when (data.size - i) {
            1 -> {
                val n = (data[i].toInt() and 0xFF) shl 16
                sb.append(B64URL[(n ushr 18) and 63]).append(B64URL[(n ushr 12) and 63])
            }
            2 -> {
                val n = ((data[i].toInt() and 0xFF) shl 16) or ((data[i + 1].toInt() and 0xFF) shl 8)
                sb.append(B64URL[(n ushr 18) and 63])
                    .append(B64URL[(n ushr 12) and 63])
                    .append(B64URL[(n ushr 6) and 63])
            }
        }
        return sb.toString()
    }

    /** Decodes base64url or standard base64, padded or not. Null if the text is not base64. */
    fun base64UrlDecode(text: String): ByteArray? {
        val out = ByteArrayOutputStream(text.length * 3 / 4 + 1)
        var buffer = 0
        var bits = 0
        for (c in text) {
            if (c == '=') break
            val v = when (c) {
                in 'A'..'Z' -> c - 'A'
                in 'a'..'z' -> c - 'a' + 26
                in '0'..'9' -> c - '0' + 52
                '-', '+' -> 62
                '_', '/' -> 63
                else -> return null
            }
            buffer = ((buffer shl 6) or v) and 0xFFFFFF
            bits += 6
            if (bits >= 8) {
                bits -= 8
                out.write((buffer shr bits) and 0xFF)
            }
        }
        return out.toByteArray()
    }

    // ========================
    // URLS / ENCODING
    // ========================

    fun buildAuthUrl(
        clientId: String,
        redirectUri: String,
        codeChallenge: String,
        state: String,
        scopes: List<String> = SCOPES,
        endpoint: String = AUTH_ENDPOINT
    ): String {
        val params = listOf(
            "client_id" to clientId,
            "redirect_uri" to redirectUri,
            "response_type" to "code",
            "scope" to scopes.joinToString(" "),
            "code_challenge" to codeChallenge,
            "code_challenge_method" to "S256",
            "state" to state,
            "access_type" to "offline",
            "prompt" to "consent"
        )
        return endpoint + "?" + encodeParams(params)
    }

    fun encodeParams(params: List<Pair<String, String>>): String =
        params.joinToString("&") { (key, value) -> urlEncode(key) + "=" + urlEncode(value) }

    /** Spaces become %20, which both query strings and form bodies accept. */
    fun urlEncode(value: String): String = URLEncoder.encode(value, "UTF-8").replace("+", "%20")

    fun parseQuery(query: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (part in query.split('&')) {
            if (part.isEmpty()) continue
            val eq = part.indexOf('=')
            val key = urlDecode(if (eq >= 0) part.substring(0, eq) else part) ?: continue
            val value = urlDecode(if (eq >= 0) part.substring(eq + 1) else "") ?: continue
            out[key] = value
        }
        return out
    }

    private fun urlDecode(text: String): String? = try {
        URLDecoder.decode(text, "UTF-8")
    } catch (e: IllegalArgumentException) {
        null
    }

    /** "GET /?code=..&state=.. HTTP/1.1" -> "code=..&state=..". Empty if no query, null if not a GET line. */
    fun queryFromRequestLine(requestLine: String): String? {
        val parts = requestLine.trim().split(' ')
        if (parts.size < 2 || parts[0] != "GET") return null
        val target = parts[1]
        val q = target.indexOf('?')
        return if (q >= 0) target.substring(q + 1).substringBefore('#') else ""
    }

    fun looksLikeClientId(clientId: String): Boolean =
        clientId.trim().endsWith(".apps.googleusercontent.com")

    // ========================
    // OAUTH TOKENS
    // ========================

    data class TokenResponse(
        val accessToken: String,
        val expiresInSec: Long,
        val refreshToken: String?,
        val scope: String?,
        val idToken: String?
    ) {
        /** Google lets the user untick scopes on the consent screen, so check what was granted. */
        fun hasScope(wanted: String): Boolean = scope == null || scope.split(' ').contains(wanted)
    }

    fun exchangeCode(
        code: String,
        codeVerifier: String,
        clientId: String,
        clientSecret: String?,
        redirectUri: String,
        tokenEndpoint: String = tokenUrl
    ): TokenResponse {
        val params = mutableListOf(
            "code" to code,
            "client_id" to clientId,
            "code_verifier" to codeVerifier,
            "grant_type" to "authorization_code",
            "redirect_uri" to redirectUri
        )
        if (!clientSecret.isNullOrBlank()) params.add("client_secret" to clientSecret)
        return tokenOrThrow(postForm(tokenEndpoint, params))
    }

    fun refreshAccessToken(
        refreshToken: String,
        clientId: String,
        clientSecret: String?,
        tokenEndpoint: String = tokenUrl
    ): TokenResponse {
        val params = mutableListOf(
            "client_id" to clientId,
            "grant_type" to "refresh_token",
            "refresh_token" to refreshToken
        )
        if (!clientSecret.isNullOrBlank()) params.add("client_secret" to clientSecret)
        return tokenOrThrow(postForm(tokenEndpoint, params))
    }

    /** Best effort; the app forgets the tokens either way. */
    fun revokeToken(token: String, endpoint: String = revokeUrl): Boolean = try {
        postForm(endpoint, listOf("token" to token)).code in 200..299
    } catch (e: IOException) {
        false
    }

    private fun tokenOrThrow(res: HttpResult): TokenResponse {
        if (res.code !in 200..299) {
            val (error, description) = oauthError(res.body)
            val text = listOfNotNull(error, description).joinToString(": ")
                .ifEmpty { apiErrorMessage(res.body) ?: "HTTP ${res.code}" }
            throw GoogleHealthException(text, res.code, error)
        }
        return parseTokenResponse(res.body)
            ?: throw GoogleHealthException("Google answered without an access_token", res.code)
    }

    fun parseTokenResponse(body: String): TokenResponse? {
        val obj = parseObject(body) ?: return null
        val access = obj.str("access_token") ?: return null
        return TokenResponse(
            accessToken = access,
            expiresInSec = obj.long("expires_in") ?: 3600L,
            refreshToken = obj.str("refresh_token"),
            scope = obj.str("scope"),
            idToken = obj.str("id_token")
        )
    }

    /** {"error":"invalid_grant","error_description":"Token has been expired or revoked."} */
    fun oauthError(body: String): Pair<String?, String?> {
        val obj = parseObject(body) ?: return Pair(null, null)
        return Pair(obj.str("error"), obj.str("error_description"))
    }

    /** {"error":{"code":403,"message":"...","status":"PERMISSION_DENIED"}} -> "PERMISSION_DENIED: ..." */
    fun apiErrorMessage(body: String): String? {
        val obj = parseObject(body) ?: return null
        val err = obj.get("error")
        if (err != null && err.isJsonObject) {
            val e = err.asJsonObject
            return listOfNotNull(e.str("status"), e.str("message")).joinToString(": ").ifEmpty { null }
        }
        return obj.str("error_description") ?: obj.str("error")
    }

    /** The `email` claim of the ID token (only used to show which account is signed in). */
    fun emailFromIdToken(idToken: String?): String? {
        if (idToken.isNullOrBlank()) return null
        val parts = idToken.split('.')
        if (parts.size < 2) return null
        val payload = base64UrlDecode(parts[1]) ?: return null
        return parseObject(String(payload, Charsets.UTF_8))?.str("email")
    }

    // ========================
    // STEPS (dailyRollUp)
    // ========================

    data class CivilDate(val year: Int, val month: Int, val day: Int)
    data class CivilTime(val hours: Int, val minutes: Int, val seconds: Int)

    fun stepsUrl(apiBase: String = apiBaseUrl): String =
        apiBase.trimEnd('/') + "/users/me/dataTypes/steps/dataPoints:dailyRollUp"

    /**
     * One civil (local) day from 00:00. [end] null = 23:59:59, as in Google's own example;
     * otherwise that time of day (used once if Google refuses a range that ends in the future).
     */
    fun stepsRequestJson(date: CivilDate, end: CivilTime?, source: String?): String {
        val endTime = end ?: CivilTime(23, 59, 59)
        val safeEnd = if (endTime.hours == 0 && endTime.minutes == 0 && endTime.seconds == 0) {
            CivilTime(0, 0, 1) // never an empty range
        } else {
            endTime
        }
        val range = JsonObject()
        range.add("start", civilDateTime(date, CivilTime(0, 0, 0)))
        range.add("end", civilDateTime(date, safeEnd))
        val body = JsonObject()
        body.add("range", range)
        body.addProperty("windowSizeDays", 1)
        if (!source.isNullOrBlank() && source != SOURCE_ALL) {
            body.addProperty("dataSourceFamily", SOURCE_PREFIX + source)
        }
        return body.toString()
    }

    private fun civilDateTime(date: CivilDate, time: CivilTime): JsonObject {
        val d = JsonObject()
        d.addProperty("year", date.year)
        d.addProperty("month", date.month)
        d.addProperty("day", date.day)
        val t = JsonObject()
        t.addProperty("hours", time.hours)
        t.addProperty("minutes", time.minutes)
        t.addProperty("seconds", time.seconds)
        t.addProperty("nanos", 0)
        val o = JsonObject()
        o.add("date", d)
        o.add("time", t)
        return o
    }

    sealed class StepsParse {
        data class Ok(val steps: Long, val empty: Boolean) : StepsParse()
        data class Bad(val reason: String) : StepsParse()
    }

    /** Sums `rollupDataPoints[].steps.countSum` (an int64, so Google sends it as a string). */
    fun parseStepsResponse(body: String): StepsParse {
        val obj = parseObject(body) ?: return StepsParse.Bad("Response is not JSON: " + body.take(120))
        val pointsEl = obj.get("rollupDataPoints")
        if (pointsEl == null || pointsEl.isJsonNull) return StepsParse.Ok(0, empty = true)
        if (!pointsEl.isJsonArray) return StepsParse.Bad("rollupDataPoints is not a list")
        val points = pointsEl.asJsonArray
        if (points.size() == 0) return StepsParse.Ok(0, empty = true)

        var sum = 0L
        var counted = false
        var sawSteps = false
        for (point in points) {
            if (!point.isJsonObject) continue
            val steps = point.asJsonObject.get("steps")
            if (steps == null || !steps.isJsonObject) continue
            sawSteps = true
            val n = steps.asJsonObject.long("countSum") ?: continue
            sum += n
            counted = true
        }
        return when {
            counted -> StepsParse.Ok(sum, empty = false)
            sawSteps -> StepsParse.Ok(0, empty = true) // a day with no recorded steps yet
            else -> StepsParse.Bad("No steps in response: " + body.take(120))
        }
    }

    /** Right-aligned in the watch's 6 digits: 8432 -> "  8432". */
    fun formatForWatch(steps: Long): String =
        steps.coerceIn(0L, 999_999L).toString().padStart(6, ' ')

    fun fetchSteps(
        accessToken: String,
        date: CivilDate,
        end: CivilTime?,
        source: String?,
        apiBase: String = apiBaseUrl
    ): HttpResult = postJson(stepsUrl(apiBase), stepsRequestJson(date, end, source), accessToken)

    // ========================
    // HTTP
    // ========================

    data class HttpResult(val code: Int, val body: String)

    fun postForm(url: String, params: List<Pair<String, String>>): HttpResult =
        post(url, "application/x-www-form-urlencoded", encodeParams(params), bearer = null)

    fun postJson(url: String, json: String, bearer: String): HttpResult =
        post(url, "application/json; charset=utf-8", json, bearer)

    /** Throws IOException when Google can't be reached; any HTTP status comes back as a result. */
    private fun post(url: String, contentType: String, body: String, bearer: String?): HttpResult {
        val conn = URI(url).toURL().openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.doOutput = true
            conn.useCaches = false
            conn.setRequestProperty("Content-Type", contentType)
            conn.setRequestProperty("Accept", "application/json")
            if (bearer != null) conn.setRequestProperty("Authorization", "Bearer $bearer")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            return HttpResult(code, text)
        } finally {
            conn.disconnect()
        }
    }

    // ========================
    // JSON
    // ========================

    private fun parseObject(body: String): JsonObject? = try {
        val el = JsonParser.parseString(body)
        if (el.isJsonObject) el.asJsonObject else null
    } catch (e: Exception) {
        null
    }

    private fun JsonObject.str(key: String): String? {
        val el = get(key) ?: return null
        return if (el.isJsonPrimitive) el.asString else null
    }

    private fun JsonObject.long(key: String): Long? {
        val el = get(key) ?: return null
        if (!el.isJsonPrimitive) return null
        return try {
            el.asLong
        } catch (e: NumberFormatException) {
            el.asString.toDoubleOrNull()?.toLong()
        }
    }

    // ========================
    // LOOPBACK REDIRECT
    // ========================

    data class RedirectResult(
        val code: String?,
        val error: String?,
        val stateMatches: Boolean,
        val scope: String?
    )

    fun htmlPage(title: String, message: String): String {
        val t = escapeHtml(title)
        val m = escapeHtml(message)
        return "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<title>$t</title><style>" +
            "body{font-family:sans-serif;margin:0;padding:56px 24px;text-align:center;background:#fff;color:#1A1A1A}" +
            "h1{font-size:22px;margin:0 0 12px}p{font-size:16px;line-height:1.5;color:#6B6B6B}" +
            "</style></head><body><h1>$t</h1><p>$m</p></body></html>"
    }

    private fun escapeHtml(text: String): String = text
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")

    /**
     * Listens once on 127.0.0.1 (random free port) for the browser to come back from Google
     * with `?code=...` or `?error=...`. Other requests (favicon, preconnects) get a 404.
     */
    class LoopbackReceiver(
        private val successHtml: String,
        private val failureHtml: String
    ) : Closeable {

        // getByAddress: no name lookup, so this is safe to create on the main thread.
        private val server = ServerSocket(0, 8, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)))
        val port: Int = server.localPort
        val redirectUri: String = "http://127.0.0.1:$port"

        /** Blocks until the redirect arrives. Throws SocketTimeoutException, or SocketException after [close]. */
        fun await(expectedState: String, timeoutMs: Long): RedirectResult {
            val deadline = System.currentTimeMillis() + timeoutMs
            while (true) {
                val remaining = deadline - System.currentTimeMillis()
                if (remaining <= 0) throw SocketTimeoutException("Timed out waiting for the browser")
                server.soTimeout = remaining.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                val socket = server.accept()
                socket.use { s ->
                    s.soTimeout = 10_000
                    val requestLine = try {
                        readRequestHead(s.getInputStream())
                    } catch (e: IOException) {
                        null
                    }
                    val query = requestLine?.let { queryFromRequestLine(it) }
                    val params = if (query.isNullOrEmpty()) emptyMap() else parseQuery(query)
                    val code = params["code"]
                    val error = params["error"]
                    if (code == null && error == null) {
                        respond(s, 404, "Not found")
                    } else {
                        val stateMatches = params["state"] == expectedState
                        val ok = stateMatches && code != null && error == null
                        respond(s, 200, if (ok) successHtml else failureHtml)
                        return RedirectResult(code, error, stateMatches, params["scope"])
                    }
                }
            }
        }

        override fun close() {
            try {
                server.close()
            } catch (e: IOException) {
                // already closed
            }
        }

        /** Reads the request head up to the blank line, so closing never resets unread bytes. */
        private fun readRequestHead(input: InputStream): String? {
            val buf = ByteArrayOutputStream()
            var matched = 0 // progress through "\r\n\r\n"
            while (buf.size() < 16 * 1024) {
                val b = input.read()
                if (b < 0) break
                buf.write(b)
                matched = when {
                    (matched == 0 || matched == 2) && b == '\r'.code -> matched + 1
                    (matched == 1 || matched == 3) && b == '\n'.code -> matched + 1
                    b == '\r'.code -> 1
                    else -> 0
                }
                if (matched == 4) break
            }
            if (buf.size() == 0) return null
            return String(buf.toByteArray(), Charsets.ISO_8859_1).lineSequence().firstOrNull()?.trim()
        }

        private fun respond(socket: Socket, status: Int, html: String) {
            val body = html.toByteArray(Charsets.UTF_8)
            val reason = if (status == 200) "OK" else "Not Found"
            val head = "HTTP/1.1 $status $reason\r\n" +
                "Content-Type: text/html; charset=utf-8\r\n" +
                "Content-Length: ${body.size}\r\n" +
                "Cache-Control: no-store\r\n" +
                "Connection: close\r\n\r\n"
            try {
                val out = socket.getOutputStream()
                out.write(head.toByteArray(Charsets.ISO_8859_1))
                out.write(body)
                out.flush()
            } catch (e: IOException) {
                // the browser went away; nothing to do
            }
        }
    }
}
