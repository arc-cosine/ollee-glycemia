package pl.cukrzycowy.ollee.glycemia.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pl.cukrzycowy.ollee.glycemia.GlycemiaProviderManager
import pl.cukrzycowy.ollee.glycemia.GoogleHealthApi
import pl.cukrzycowy.ollee.glycemia.GoogleHealthAuth
import pl.cukrzycowy.ollee.glycemia.GoogleHealthFetchResult
import pl.cukrzycowy.ollee.glycemia.GoogleHealthFetchStateStore
import pl.cukrzycowy.ollee.glycemia.GoogleHealthFetchStatus
import pl.cukrzycowy.ollee.glycemia.GoogleHealthProvider
import pl.cukrzycowy.ollee.glycemia.ProviderConfigOption
import pl.cukrzycowy.ollee.glycemia.R
import pl.cukrzycowy.ollee.glycemia.ui.components.FullScreenScaffold
import pl.cukrzycowy.ollee.glycemia.ui.components.PillButton
import pl.cukrzycowy.ollee.glycemia.ui.components.PillButtonStyle
import pl.cukrzycowy.ollee.glycemia.ui.components.SectionLabel
import pl.cukrzycowy.ollee.glycemia.ui.theme.OlleeColors
import pl.cukrzycowy.ollee.glycemia.ui.theme.OlleeSpacing
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Settings for the Google Health (steps) source, laid out like the Nightscout screen:
 * the OAuth client ("API key") fields, Google sign-in, a test fetch, update options,
 * last-fetch diagnostics and Save.
 */
@Composable
fun GoogleHealthProviderConfigScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val provider = remember {
        GlycemiaProviderManager.allProviders.filterIsInstance<GoogleHealthProvider>().firstOrNull()
            ?: GoogleHealthProvider()
    }
    val spec = remember { provider.getConfigSpec(context) }
    val savedValues = remember { provider.getSavedConfig(context) }

    var clientId by remember { mutableStateOf(savedValues[GoogleHealthProvider.KEY_CLIENT_ID] ?: "") }
    var clientSecret by remember { mutableStateOf(GoogleHealthAuth.getClientSecret(context)) }
    var interval by remember {
        mutableStateOf(savedValues[GoogleHealthProvider.KEY_INTERVAL] ?: GoogleHealthProvider.INTERVAL_5_MINUTES)
    }
    var source by remember {
        mutableStateOf(savedValues[GoogleHealthProvider.KEY_SOURCE] ?: GoogleHealthApi.SOURCE_ALL)
    }
    var clientIdFocused by remember { mutableStateOf(false) }
    var secretFocused by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testError by remember { mutableStateOf<String?>(null) }
    var lastFetch by remember { mutableStateOf(GoogleHealthFetchStateStore.read(context)) }
    val authState by GoogleHealthAuth.state.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    val intervalOptions = spec.fields.firstOrNull { it.key == GoogleHealthProvider.KEY_INTERVAL }?.options ?: emptyList()
    val sourceOptions = spec.fields.firstOrNull { it.key == GoogleHealthProvider.KEY_SOURCE }?.options ?: emptyList()

    LaunchedEffect(Unit) {
        GoogleHealthAuth.loadState(context)
        while (true) {
            delay(3000)
            lastFetch = GoogleHealthFetchStateStore.read(context)
        }
    }

    fun persistSettings() {
        provider.saveConfig(
            context,
            mapOf(
                GoogleHealthProvider.KEY_CLIENT_ID to clientId.trim(),
                GoogleHealthProvider.KEY_INTERVAL to interval,
                GoogleHealthProvider.KEY_SOURCE to source
            )
        )
        GoogleHealthAuth.setClientSecret(context, clientSecret)
    }

    FullScreenScaffold(title = spec.title, onBack = onBack) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(vertical = OlleeSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(OlleeSpacing.lg)
        ) {
            // Client ID ("API key")
            SectionLabel(text = stringResource(R.string.provider_google_health_client_id_label))
            OutlinedTextField(
                value = clientId,
                onValueChange = { clientId = it },
                modifier = Modifier.fillMaxWidth().onFocusChanged { clientIdFocused = it.isFocused },
                placeholder = { Text("1234567890-abc123.apps.googleusercontent.com") },
                singleLine = true
            )
            if (clientIdFocused) {
                HelperRow(stringResource(R.string.provider_google_health_client_id_helper))
            }
            if (clientId.isNotBlank() && !GoogleHealthApi.looksLikeClientId(clientId)) {
                Text(
                    text = "⚠ " + stringResource(R.string.provider_google_health_client_id_warning),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            // Client secret
            SectionLabel(text = stringResource(R.string.provider_google_health_client_secret_label))
            OutlinedTextField(
                value = clientSecret,
                onValueChange = { clientSecret = it },
                modifier = Modifier.fillMaxWidth().onFocusChanged { secretFocused = it.isFocused },
                placeholder = { Text("GOCSPX-…") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
            if (secretFocused) {
                HelperRow(stringResource(R.string.provider_google_health_client_secret_helper))
            }

            // Google account
            SectionLabel(text = stringResource(R.string.provider_google_health_account_label))
            val email = authState.email
            MessageRow(
                symbol = if (authState.signedIn) "✓" else "–",
                text = when {
                    !authState.signedIn -> stringResource(R.string.provider_google_health_not_signed_in)
                    email != null -> stringResource(R.string.provider_google_health_signed_in_as, email)
                    else -> stringResource(R.string.provider_google_health_signed_in)
                },
                isError = false
            )

            PillButton(
                text = stringResource(
                    if (authState.signedIn) R.string.provider_google_health_sign_in_again
                    else R.string.provider_google_health_sign_in
                ),
                icon = Icons.Default.AccountCircle,
                style = PillButtonStyle.PRIMARY,
                enabled = clientId.isNotBlank(),
                onClick = {
                    persistSettings()
                    GoogleHealthAuth.startSignIn(context, clientId, clientSecret)
                }
            )

            val authMessage = authState.message
            if (authState.inProgress) {
                ProgressRow(authMessage ?: stringResource(R.string.provider_google_health_waiting_browser))
            } else if (authMessage != null) {
                MessageRow(
                    symbol = if (authState.isError) "✗" else "✓",
                    text = authMessage,
                    isError = authState.isError
                )
            }

            if (authState.signedIn) {
                PillButton(
                    text = stringResource(R.string.provider_google_health_sign_out),
                    icon = Icons.Default.Close,
                    style = PillButtonStyle.SECONDARY_DARK,
                    onClick = { GoogleHealthAuth.signOut(context) }
                )
            }

            // Test fetch
            PillButton(
                text = if (testing)
                    stringResource(R.string.provider_google_health_testing)
                else
                    stringResource(R.string.provider_google_health_test),
                icon = Icons.Default.Refresh,
                style = PillButtonStyle.PRIMARY,
                enabled = !testing && authState.signedIn,
                onClick = {
                    testing = true
                    testResult = null
                    testError = null

                    coroutineScope.launch {
                        try {
                            val result = withContext(Dispatchers.IO) {
                                GoogleHealthProvider.fetchTodaySteps(context, source)
                            }
                            when (result) {
                                is GoogleHealthFetchResult.Success -> {
                                    testResult = context.getString(
                                        R.string.provider_google_health_test_ok,
                                        result.steps,
                                        GoogleHealthApi.formatForWatch(result.steps)
                                    )
                                }
                                is GoogleHealthFetchResult.Failure -> {
                                    testError = result.detail
                                }
                            }
                        } catch (e: Exception) {
                            testError = context.getString(
                                R.string.provider_google_health_error_network,
                                e.message ?: "Unknown error"
                            )
                        } finally {
                            testing = false
                            lastFetch = GoogleHealthFetchStateStore.read(context)
                        }
                    }
                }
            )

            if (testing) {
                ProgressRow(stringResource(R.string.provider_google_health_testing))
            }
            testResult?.let { result ->
                MessageRow(symbol = "✓", text = result, isError = false)
            }
            testError?.let { error ->
                MessageRow(symbol = "✗", text = error, isError = true)
            }

            // Update options
            SectionLabel(text = stringResource(R.string.provider_google_health_interval_label))
            ChoiceField(options = intervalOptions, selected = interval, onSelected = { interval = it })

            SectionLabel(text = stringResource(R.string.provider_google_health_source_label))
            ChoiceField(options = sourceOptions, selected = source, onSelected = { source = it })

            // Last fetch diagnostics
            lastFetch?.let { state ->
                SectionLabel(text = stringResource(R.string.provider_google_health_last_fetch_title))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.small
                        )
                        .padding(OlleeSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(OlleeSpacing.sm)
                ) {
                    FetchDiagnosticRow("Status", fetchStatusLabel(context, state.status))
                    FetchDiagnosticRow("Time", formatFetchTime(state.atMillis))
                    state.steps?.let {
                        FetchDiagnosticRow("Steps", it.toString())
                    }
                    state.detail?.let {
                        FetchDiagnosticRow("Detail", it)
                    }
                    state.httpCode?.let {
                        FetchDiagnosticRow("HTTP Code", it.toString())
                    }
                }
            }

            // Save button
            PillButton(
                text = stringResource(R.string.provider_config_save),
                icon = Icons.Default.Save,
                style = PillButtonStyle.PRIMARY,
                onClick = {
                    persistSettings()
                    provider.refreshNow()
                    onBack()
                }
            )
        }
    }
}

@Composable
private fun HelperRow(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = OlleeSpacing.xs, start = OlleeSpacing.xs),
        horizontalArrangement = Arrangement.spacedBy(OlleeSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Filled.Info,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = OlleeColors.HelpText
        )
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = OlleeColors.HelpText
        )
    }
}

@Composable
private fun ProgressRow(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.small
            )
            .padding(OlleeSpacing.md),
        horizontalArrangement = Arrangement.spacedBy(OlleeSpacing.md),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularProgressIndicator(modifier = Modifier.size(16.dp))
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MessageRow(symbol: String, text: String, isError: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.small
            )
            .padding(OlleeSpacing.md),
        horizontalArrangement = Arrangement.spacedBy(OlleeSpacing.md)
    ) {
        Text(symbol, style = MaterialTheme.typography.labelLarge)
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChoiceField(
    options: List<ProviderConfigOption>,
    selected: String,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = options.find { it.value == selected }?.label ?: "",
            onValueChange = {},
            readOnly = true,
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor(),
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.label) },
                    onClick = {
                        onSelected(option.value)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun FetchDiagnosticRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontStyle = FontStyle.Italic
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            maxLines = 3
        )
    }
}

private fun fetchStatusLabel(context: Context, status: GoogleHealthFetchStatus): String {
    return when (status) {
        GoogleHealthFetchStatus.NEVER_RUN -> context.getString(R.string.provider_nightscout_fetch_status_never_run)
        GoogleHealthFetchStatus.OK -> context.getString(R.string.provider_nightscout_fetch_status_ok)
        GoogleHealthFetchStatus.NOT_SIGNED_IN -> context.getString(R.string.provider_google_health_not_signed_in)
        GoogleHealthFetchStatus.AUTH_ERROR -> context.getString(R.string.provider_nightscout_fetch_status_auth_error)
        GoogleHealthFetchStatus.CONNECTION_ERROR -> context.getString(R.string.provider_nightscout_fetch_status_connection_error)
        GoogleHealthFetchStatus.SERVER_ERROR -> context.getString(R.string.provider_nightscout_fetch_status_server_error)
        GoogleHealthFetchStatus.INVALID_RESPONSE -> context.getString(R.string.provider_nightscout_fetch_status_invalid_response)
    }
}

private fun formatFetchTime(timestampMs: Long): String {
    if (timestampMs == 0L) return "--"
    return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestampMs))
}
