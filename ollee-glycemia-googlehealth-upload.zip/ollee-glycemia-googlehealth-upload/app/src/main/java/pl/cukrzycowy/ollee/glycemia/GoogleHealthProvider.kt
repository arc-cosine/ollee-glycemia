package pl.cukrzycowy.ollee.glycemia

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.IOException
import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger

enum class GoogleHealthFetchStatus {
    NEVER_RUN,
    OK,
    NOT_SIGNED_IN,
    AUTH_ERROR,
    CONNECTION_ERROR,
    SERVER_ERROR,
    INVALID_RESPONSE
}

sealed class GoogleHealthFetchResult {
    data class Success(val steps: Long, val empty: Boolean) : GoogleHealthFetchResult()
    data class Failure(
        val status: GoogleHealthFetchStatus,
        val detail: String,
        val httpCode: Int? = null
    ) : GoogleHealthFetchResult()
}

data class GoogleHealthFetchState(
    val status: GoogleHealthFetchStatus,
    val atMillis: Long,
    val steps: Long?,
    val detail: String?,
    val httpCode: Int?
)

/** Last fetch outcome, for the diagnostics block of the settings screen. */
object GoogleHealthFetchStateStore {
    private const val PREFS_NAME = "google_health_auth"
    private const val KEY_STATUS = "fetch_status"
    private const val KEY_AT = "fetch_at"
    private const val KEY_STEPS = "fetch_steps"
    private const val KEY_DETAIL = "fetch_detail"
    private const val KEY_HTTP = "fetch_http_code"

    fun write(context: Context, result: GoogleHealthFetchResult) {
        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        editor.putLong(KEY_AT, System.currentTimeMillis())
        when (result) {
            is GoogleHealthFetchResult.Success -> {
                editor.putString(KEY_STATUS, GoogleHealthFetchStatus.OK.name)
                editor.putLong(KEY_STEPS, result.steps)
                editor.remove(KEY_DETAIL)
                editor.remove(KEY_HTTP)
            }
            is GoogleHealthFetchResult.Failure -> {
                // The last good step count is kept for reference.
                editor.putString(KEY_STATUS, result.status.name)
                editor.putString(KEY_DETAIL, result.detail.take(300))
                if (result.httpCode != null) editor.putInt(KEY_HTTP, result.httpCode) else editor.remove(KEY_HTTP)
            }
        }
        editor.apply()
    }

    fun read(context: Context): GoogleHealthFetchState? {
        val p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val statusName = p.getString(KEY_STATUS, null) ?: return null
        val status = GoogleHealthFetchStatus.entries.firstOrNull { it.name == statusName } ?: return null
        return GoogleHealthFetchState(
            status = status,
            atMillis = p.getLong(KEY_AT, 0L),
            steps = if (p.contains(KEY_STEPS)) p.getLong(KEY_STEPS, 0L) else null,
            detail = p.getString(KEY_DETAIL, null),
            httpCode = if (p.contains(KEY_HTTP)) p.getInt(KEY_HTTP, 0) else null
        )
    }
}

/**
 * Google Health API source (Fitbit / Pixel Watch data in the user's Google account):
 * today's step count, shown on the watch's six digits instead of a glucose value
 * (8432 steps -> "  8432"). Sign-in and the OAuth client live in [GoogleHealthAuth].
 */
class GoogleHealthProvider : ConfigurableGlycemiaProvider {

    override val id: String = ID
    override val displayName: String = "Google Health"

    private val handler = Handler(Looper.getMainLooper())
    private val generation = AtomicInteger(0)

    @Volatile
    private var callback: ((GlycemiaReading) -> Unit)? = null

    @Volatile
    private var appContext: Context? = null

    override fun start(context: Context, onReading: (GlycemiaReading) -> Unit) {
        Log.d(TAG, "Starting Google Health provider")
        appContext = context.applicationContext
        callback = onReading
        val gen = generation.incrementAndGet()
        handler.removeCallbacksAndMessages(null)
        Thread { fetchAndSchedule(gen) }.start()
    }

    override fun stop(context: Context) {
        Log.d(TAG, "Stopping Google Health provider")
        generation.incrementAndGet()
        handler.removeCallbacksAndMessages(null)
        callback = null
    }

    /** Fetch right away (after sign-in or new settings) when this provider is running. */
    fun refreshNow() {
        if (callback == null) return
        val gen = generation.incrementAndGet()
        handler.removeCallbacksAndMessages(null)
        Thread { fetchAndSchedule(gen) }.start()
    }

    private fun fetchAndSchedule(gen: Int) {
        val context = appContext ?: return
        if (gen != generation.get()) return

        val config = getSavedConfig(context)
        val intervalMs = if (config[KEY_INTERVAL] == INTERVAL_1_MINUTE) 60_000L else 300_000L
        val result = try {
            fetchTodaySteps(context, config[KEY_SOURCE] ?: GoogleHealthApi.SOURCE_ALL)
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected fetch failure", e)
            GoogleHealthFetchResult.Failure(
                GoogleHealthFetchStatus.INVALID_RESPONSE,
                e.message ?: e.javaClass.simpleName
            )
        }
        if (gen != generation.get()) return

        val nextDelayMs = when (result) {
            is GoogleHealthFetchResult.Success -> {
                val reading = GlycemiaReading(
                    bg = context.getString(R.string.provider_google_health_steps_value, result.steps),
                    trend = null,
                    delta = null,
                    timestamp = System.currentTimeMillis(),
                    display = GoogleHealthApi.formatForWatch(result.steps)
                )
                Log.d(TAG, "Steps today: ${result.steps}")
                handler.post {
                    if (gen == generation.get()) callback?.invoke(reading)
                }
                intervalMs
            }
            is GoogleHealthFetchResult.Failure -> {
                Log.w(TAG, "Fetch failed: ${result.status} ${result.detail}")
                if (result.status == GoogleHealthFetchStatus.NOT_SIGNED_IN) intervalMs else minOf(intervalMs, RETRY_MS)
            }
        }
        handler.postDelayed({ Thread { fetchAndSchedule(gen) }.start() }, nextDelayMs)
    }

    override fun getConfigSpec(context: Context): ProviderConfigSpec {
        return ProviderConfigSpec(
            title = context.getString(R.string.provider_google_health_config_title),
            fields = listOf(
                ProviderConfigField(
                    key = KEY_CLIENT_ID,
                    label = context.getString(R.string.provider_google_health_client_id_label),
                    type = ProviderConfigField.FieldType.TEXT,
                    defaultValue = "",
                    helperText = context.getString(R.string.provider_google_health_client_id_helper)
                ),
                ProviderConfigField(
                    key = KEY_INTERVAL,
                    label = context.getString(R.string.provider_google_health_interval_label),
                    type = ProviderConfigField.FieldType.CHOICE,
                    defaultValue = INTERVAL_5_MINUTES,
                    options = listOf(
                        ProviderConfigOption(INTERVAL_1_MINUTE, context.getString(R.string.provider_interval_1m)),
                        ProviderConfigOption(INTERVAL_5_MINUTES, context.getString(R.string.provider_interval_5m))
                    )
                ),
                ProviderConfigField(
                    key = KEY_SOURCE,
                    label = context.getString(R.string.provider_google_health_source_label),
                    type = ProviderConfigField.FieldType.CHOICE,
                    defaultValue = GoogleHealthApi.SOURCE_ALL,
                    options = listOf(
                        ProviderConfigOption(GoogleHealthApi.SOURCE_ALL, context.getString(R.string.provider_google_health_source_all)),
                        ProviderConfigOption(GoogleHealthApi.SOURCE_WEARABLES, context.getString(R.string.provider_google_health_source_wearables))
                    )
                )
            )
        )
    }

    override fun getSavedConfig(context: Context): Map<String, String> {
        return ProviderConfigStore.read(context, id, getConfigSpec(context))
    }

    override fun saveConfig(context: Context, values: Map<String, String>) {
        val normalized = mutableMapOf<String, String>()
        normalized[KEY_CLIENT_ID] = values[KEY_CLIENT_ID]?.trim() ?: savedClientId(context)
        normalized[KEY_INTERVAL] = values[KEY_INTERVAL]
            ?.takeIf { it == INTERVAL_1_MINUTE || it == INTERVAL_5_MINUTES }
            ?: INTERVAL_5_MINUTES
        normalized[KEY_SOURCE] = values[KEY_SOURCE]
            ?.takeIf { it == GoogleHealthApi.SOURCE_ALL || it == GoogleHealthApi.SOURCE_WEARABLES }
            ?: GoogleHealthApi.SOURCE_ALL
        ProviderConfigStore.write(context, id, normalized)
    }

    override fun getConfigSummary(context: Context): String {
        if (!GoogleHealthAuth.isSignedIn(context)) {
            return context.getString(R.string.provider_google_health_not_signed_in)
        }
        val email = GoogleHealthAuth.signedInEmail(context)
        return if (email != null) {
            context.getString(R.string.provider_google_health_signed_in_as, email)
        } else {
            context.getString(R.string.provider_google_health_signed_in)
        }
    }

    companion object {
        const val ID = "google_health"
        const val KEY_CLIENT_ID = "client_id"
        const val KEY_INTERVAL = "interval_mode"
        const val KEY_SOURCE = "data_source"
        const val INTERVAL_1_MINUTE = "1_minute"
        const val INTERVAL_5_MINUTES = "5_minutes"

        private const val TAG = "GoogleHealthProvider"
        private const val RETRY_MS = 60_000L

        /** Set once Google refused a full-day range ending in the future (HTTP 400). */
        @Volatile
        private var preferEndAtNow = false

        fun savedClientId(context: Context): String {
            val spec = ProviderConfigSpec(
                title = "",
                fields = listOf(
                    ProviderConfigField(
                        key = KEY_CLIENT_ID,
                        label = "",
                        type = ProviderConfigField.FieldType.TEXT,
                        defaultValue = ""
                    )
                )
            )
            return (ProviderConfigStore.read(context, ID, spec)[KEY_CLIENT_ID] ?: "").trim()
        }

        fun refreshRunningProvider() {
            GlycemiaProviderManager.allProviders
                .filterIsInstance<GoogleHealthProvider>()
                .forEach { it.refreshNow() }
        }

        /** Today's steps (local calendar day). Blocking: call off the main thread. */
        fun fetchTodaySteps(context: Context, source: String): GoogleHealthFetchResult {
            val appContext = context.applicationContext
            val result = fetchTodayStepsInternal(appContext, source)
            GoogleHealthFetchStateStore.write(appContext, result)
            return result
        }

        private fun fetchTodayStepsInternal(context: Context, source: String): GoogleHealthFetchResult {
            var token = when (val t = GoogleHealthAuth.getValidAccessToken(context)) {
                is GoogleHealthAuth.TokenResult.Ok -> t.accessToken
                is GoogleHealthAuth.TokenResult.NotSignedIn ->
                    return GoogleHealthFetchResult.Failure(GoogleHealthFetchStatus.NOT_SIGNED_IN, t.reason)
                is GoogleHealthAuth.TokenResult.Failed ->
                    return GoogleHealthFetchResult.Failure(t.status, t.reason, t.httpCode)
            }

            val now = Calendar.getInstance()
            val date = GoogleHealthApi.CivilDate(
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH) + 1,
                now.get(Calendar.DAY_OF_MONTH)
            )
            val timeNow = GoogleHealthApi.CivilTime(
                now.get(Calendar.HOUR_OF_DAY),
                now.get(Calendar.MINUTE),
                now.get(Calendar.SECOND)
            )

            var endAtNow = preferEndAtNow
            var triedOtherRange = false
            var refreshed = false
            while (true) {
                val res = try {
                    GoogleHealthApi.fetchSteps(token, date, if (endAtNow) timeNow else null, source)
                } catch (e: IOException) {
                    return GoogleHealthFetchResult.Failure(
                        GoogleHealthFetchStatus.CONNECTION_ERROR,
                        e.message ?: e.javaClass.simpleName
                    )
                }

                when {
                    res.code in 200..299 -> return when (val parsed = GoogleHealthApi.parseStepsResponse(res.body)) {
                        is GoogleHealthApi.StepsParse.Ok -> {
                            preferEndAtNow = endAtNow
                            GoogleHealthFetchResult.Success(parsed.steps, parsed.empty)
                        }
                        is GoogleHealthApi.StepsParse.Bad ->
                            GoogleHealthFetchResult.Failure(GoogleHealthFetchStatus.INVALID_RESPONSE, parsed.reason, res.code)
                    }

                    res.code == 401 && !refreshed -> {
                        refreshed = true
                        token = when (val t = GoogleHealthAuth.getValidAccessToken(context, forceRefresh = true)) {
                            is GoogleHealthAuth.TokenResult.Ok -> t.accessToken
                            is GoogleHealthAuth.TokenResult.NotSignedIn ->
                                return GoogleHealthFetchResult.Failure(GoogleHealthFetchStatus.NOT_SIGNED_IN, t.reason)
                            is GoogleHealthAuth.TokenResult.Failed ->
                                return GoogleHealthFetchResult.Failure(t.status, t.reason, t.httpCode)
                        }
                    }

                    res.code == 400 && !triedOtherRange -> {
                        // Google may refuse a range that ends in the future; try the other end once.
                        triedOtherRange = true
                        endAtNow = !endAtNow
                    }

                    else -> {
                        val detail = GoogleHealthApi.apiErrorMessage(res.body) ?: "HTTP ${res.code}"
                        val status = when (res.code) {
                            401, 403 -> GoogleHealthFetchStatus.AUTH_ERROR
                            in 500..599 -> GoogleHealthFetchStatus.SERVER_ERROR
                            else -> GoogleHealthFetchStatus.INVALID_RESPONSE
                        }
                        return GoogleHealthFetchResult.Failure(status, detail, res.code)
                    }
                }
            }
        }
    }
}
