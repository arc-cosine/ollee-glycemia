package pl.cukrzycowy.ollee.glycemia

data class GlycemiaReading(
    val bg: String,
    val trend: String?,
    val delta: Double?,
    val timestamp: Long = System.currentTimeMillis(),
    /**
     * Ready-made 6-character text for the watch. When set, it is sent as-is instead of
     * being formatted as a glucose value, and the reading stays out of the glucose
     * history (e.g. the Google Health step count).
     */
    val display: String? = null
)
