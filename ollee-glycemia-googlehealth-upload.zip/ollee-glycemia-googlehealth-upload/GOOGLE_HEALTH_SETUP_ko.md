# Ollee Glycemia + Google Health 걸음수

기존 앱 디자인은 그대로 두고, 소스(Glucose Source) 목록에 **Google Health (steps)** 를 추가한 버전이에요.
오늘 걸음수를 Google Health API에서 5분(또는 1분)마다 가져와 시계 6자리에 보냅니다. 8432보 → `  8432`

## 바뀐 파일

| 파일 | 내용 |
| --- | --- |
| `GoogleHealthApi.kt` (새 파일) | OAuth(PKCE + 127.0.0.1 리디렉션), steps `dailyRollUp` 요청/파싱, 시계 6자리 포맷 |
| `GoogleHealthAuth.kt` (새 파일) | 구글 로그인, 토큰 저장/갱신(앱 전용 저장소, 백업 제외) |
| `GoogleHealthProvider.kt` (새 파일) | 소스 본체: 주기적으로 걸음수 조회 → 시계로 전송 |
| `ui/screens/GoogleHealthProviderConfigScreen.kt` (새 파일) | 설정 화면: Client ID(API 키)·Client secret 입력, 로그인, 테스트, 주기, 데이터 소스, 진단, 저장 |
| `GlycemiaReading.kt` | `display` 필드 추가 (기본값 null이라 기존 소스는 영향 없음) |
| `BleService.kt` | `display`가 있으면 그대로 전송 (혈당 포맷의 0–999 제한 우회), 걸음수는 혈당 그래프에 안 넣음 |
| `GlycemiaProviderManager.kt`, `AppNavHost.kt`, `MainScreen.kt` | 소스 등록, 설정 화면 연결, 이름 표시 |
| `values*/strings.xml` | 영어·프랑스어·폴란드어 문구 39개 |
| `app/build.gradle.kts`, `app/debug.keystore` | 고정 디버그 서명 키 → 다음 빌드도 삭제 없이 덮어쓰기 설치 |
| `GoogleHealthApiTest.kt` (새 파일) | 단위 테스트 8개 |

## 1. Google Cloud 설정 (한 번만)

1. [console.cloud.google.com](https://console.cloud.google.com) 에서 프로젝트 선택 (참고 문서에서 만든 프로젝트를 써도 돼요)
2. **API 및 서비스 → 라이브러리** → `Google Health API` 검색 → **사용**
3. **API 및 서비스 → 사용자 인증 정보 → 사용자 인증 정보 만들기 → OAuth 클라이언트 ID**
   - 처음이면 동의 화면 구성: 앱 이름, 지원 이메일 → **외부(External)** → 연락처 이메일 → 동의 → 만들기
4. **대상(Audience)**: 게시 상태 "테스트" 확인 → **테스트 사용자**에 핏빗이 연결된 내 구글 계정 추가 → 저장
5. **데이터 액세스(Data Access)** → 범위 추가 또는 삭제 → `googlehealth.activity_and_fitness.readonly` 체크 → 업데이트 → 저장
6. **클라이언트(Clients) → 클라이언트 만들기 → 애플리케이션 유형: 데스크톱 앱** → 만들기
   → **클라이언트 ID**와 **클라이언트 보안 비밀번호(GOCSPX-…)** 를 복사

> 참고 문서의 "웹 애플리케이션" 클라이언트는 이 앱에선 안 돼요 (리디렉션 방식이 달라요). 꼭 **데스크톱 앱** 유형으로 하나 더 만드세요.

## 2. APK 만들기 (GitHub Actions)

여기 작업 환경은 구글/메이븐 서버가 막혀 있어서 APK를 직접 빌드할 수 없었어요. 저장소에 이미 있는 자동 빌드를 쓰면 됩니다.

1. [github.com/dlvoy/ollee-glycemia](https://github.com/dlvoy/ollee-glycemia) → **Fork**
2. 내 포크 → **Actions** 탭 → "I understand my workflows, go ahead and enable them"
3. `ollee-glycemia-googlehealth-upload.zip` 압축 해제 → 포크 첫 화면 **Add file → Upload files** → 압축 푼 폴더 안의 **`app` 폴더를 통째로** 끌어다 놓기 → **Commit changes**
4. **Actions → Build APK** 가 자동 실행 (5–10분) → 끝난 실행을 열고 맨 아래 **Artifacts** 의 apk 다운로드 → 압축 풀어서 폰에 설치 ("출처를 알 수 없는 앱" 허용)

- **Verify Commit Authors** 가 빨간 X여도 무시해도 돼요 (커밋 이메일 형식 검사일 뿐, APK와 무관).
- 공식 Ollee Glycemia가 이미 깔려 있으면 서명이 달라서 먼저 삭제해야 설치돼요. (앱의 백업 내보내기/가져오기로 설정 옮기기 가능)
- Android Studio가 있으면 `ollee-glycemia-googlehealth-full.zip` 을 열고 Run 해도 돼요.

## 3. 앱에서

1. 메인 화면 소스 카드의 **⇄** → **Google Health (steps)**
2. **연필** → Client ID, Client secret 붙여넣기 → **Sign in with Google**
3. 브라우저에서 핏빗 연결 계정 선택 → "Google에서 확인하지 않은 앱" → **계속** → 활동·피트니스 데이터 허용 → "Signed in" 페이지가 뜨면 앱으로 돌아오기
4. **Fetch today's steps** 로 확인 → **Save**
5. 시계 페어링은 기존과 같아요. 시계의 글리세미아 화면에 걸음수가 떠요.

## 알아둘 것

- 게시 상태가 "테스트"인 OAuth 앱은 구글 정책상 **7일마다 다시 로그인**해야 해요. 만료되면 설정 화면에 안내가 뜨고, 시계는 기존 규칙대로 `Err` 를 보여줘요.
- 걸음수는 핏빗(Google Health) 앱이 클라우드에 동기화한 만큼만 보여요. 실시간은 아니에요.
- Client secret과 토큰은 폰 안 앱 전용 저장소에만 있어요 (앱 백업 파일에도 안 들어가요). 채팅이나 남에게 붙여넣지 마세요.
- 조회가 실패하면 1분 뒤 다시 시도해요. 5분 넘게 새 값이 없으면 앱이 기존처럼 Late/Stale 로 표시해요.
